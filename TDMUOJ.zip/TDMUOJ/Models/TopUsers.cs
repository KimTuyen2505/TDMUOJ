﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TDMUOJ.Models
{
    public class TopUsers
    {
        public List<Account> AccountList { get; set; }
        public List<Problem> NewProblemList { get; set; }

    }
}