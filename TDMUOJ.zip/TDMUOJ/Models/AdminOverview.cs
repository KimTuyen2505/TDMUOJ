﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TDMUOJ.Models
{
    public class AdminOverview
    {
        public int accountNumber { get; set; }
        public int problemNumber { get; set; }
        public int contestNumber { get; set; }
        public int submissionNumber { get; set; }
        
    }
}