﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TDMUOJ.Models
{
	public class ContestEndedCustom
	{
        public Contest contest { get; set; }
        public int participantedCount { get; set; }
    }
}